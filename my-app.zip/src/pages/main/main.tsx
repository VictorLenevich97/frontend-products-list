import React from "react";
import Main from "../../modules/main";

const PageMain = () => <Main />;

export default PageMain;
