import * as antd from "antd";
import styled from "styled-components";

export const Layout = styled(antd.Layout)`
  height: 100vh;
`;
