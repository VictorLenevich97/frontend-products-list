export const mainTheme = {
  main: "mediumseagreen",
};
