export const PAGE_DETAIL = "/page-detail";
