module.exports = {
  "primary-color": "#1890ff",
};
